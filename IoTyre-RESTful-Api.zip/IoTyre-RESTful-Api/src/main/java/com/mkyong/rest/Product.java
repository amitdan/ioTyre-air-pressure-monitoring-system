package com.mkyong.rest;

public class Product {

	String fname;
	String lname;
	long mobile;
	String vehicle;
	

	public String getFname() {
		return fname;
	}


	public void setFname(String fname) {
		this.fname = fname;
	}


	public String getLname() {
		return lname;
	}


	public void setLname(String lname) {
		this.lname = lname;
	}


	public long getMobile() {
		return mobile;
	}


	public void setMobile(long mobile) {
		this.mobile = mobile;
	}


	public String getVehicle() {
		return vehicle;
	}


	public void setVehicle(String vehicle) {
		this.vehicle = vehicle;
	}


	@Override
	public String toString() {
		return "Details [First name=" + fname + ", Last name=" + lname + ", Mobile="+mobile+",vehicle="+vehicle+"]";
	}

}