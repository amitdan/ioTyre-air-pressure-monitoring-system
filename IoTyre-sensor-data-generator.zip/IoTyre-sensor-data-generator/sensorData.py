
# Script to generate simulated IoT device parameters data

import json
import random
import datetime
import boto3
import time

deviceNames = ['FrontTyreLeft', 'FrontTyreRight', 'RearTyreLeft', 'RearTyreRight']

vehicleNo = ['MH14CN7099', 'MH12BP0099', 'MH02BP0099', 'MH11CN7199']

iot = boto3.client('iot-data');

def getFrontRightValues():
    data = {}
    data['heightOfSensorFromGround'] = random.randint(6, 10)
    data['vehicleNumber'] = random.choice(vehicleNo)
    data['deviceId'] = random.choice(deviceNames)
    data['dateTime'] = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    return data

def getFrontLeftValues():
    data = {}
    data['heightOfSensorFromGround'] = random.randint(1, 5)
    data['vehicleNumber'] = random.choice(vehicleNo)
    data['deviceId'] = random.choice(deviceNames)
    data['dateTime'] = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    return data

def getRearRightValues():
    data = {}
    data['heightOfSensorFromGround'] = random.randint(5, 9)
    data['vehicleNumber'] = random.choice(vehicleNo)
    data['deviceId'] = random.choice(deviceNames)
    data['dateTime'] = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    return data

def getRearLeftValues():
    data = {}
    data['heightOfSensorFromGround'] = random.randint(1, 4)
    data['vehicleNumber'] = random.choice(vehicleNo)
    data['deviceId'] = random.choice(deviceNames)
    data['dateTime'] = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    return data

# Generate each parameter's data input in varying proportions
while True:
    time.sleep(1)
    rnd = random.random()
    if (0 <= rnd < 0.20):
        data = json.dumps(getFrontRightValues())
        print data
        response = iot.publish(
             topic='/sbs/devicedata/a',
             payload=data
        ) 
    elif (0.20<= rnd < 0.55):
        data = json.dumps(getFrontLeftValues())
        print data
        response = iot.publish(
             topic='/sbs/devicedata/b',
             payload=data
        )
    elif (0.55<= rnd < 0.70):
        data = json.dumps(getRearRightValues())
        print data
        response = iot.publish(
             topic='/sbs/devicedata/c',
             payload=data
        )
    else:
        data = json.dumps(getRearLeftValues())
        print data
        response = iot.publish(
             topic='/sbs/devicedata/d',
             payload=data     
)